fx_version 'cerulean'
game 'gta5'

author 'R.Robertson - Echo Kilo Studios'
description 'Vote to End or Continue Patrol'
version '1.0.0'

server_script 'server.lua'
