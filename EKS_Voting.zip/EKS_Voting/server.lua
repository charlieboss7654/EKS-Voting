local votes = {
    ["end"] = {},
    continue = {}
}

local votingInProgress = false
local voteType = nil
local voteStarter = nil
local voteTimeout = 60 -- seconds

local function hasPermission(source)
    return IsPlayerAceAllowed(source, "votecontrol")
end

local function resetVotes()
    votes["end"] = {}
    votes.continue = {}
    voteType = nil
    voteStarter = nil
    votingInProgress = false
end

local function announceResults()
    local endCount = #votes["end"]
    local continueCount = #votes.continue

    TriggerClientEvent('chat:addMessage', -1, {
        args = {
            "^3[Patrol Vote]",
            ("Vote ended! ^1End Patrol: %d ^7| ^2Continue Patrol: %d"):format(endCount, continueCount)
        }
    })

    resetVotes()
end

local function startVote(source, type)
    if votingInProgress then
        TriggerClientEvent('chat:addMessage', source, {
            args = { '^1[Voting]', 'A vote is already in progress!' }
        })
        return
    end

    votingInProgress = true
    voteType = type
    voteStarter = source

    TriggerClientEvent('chat:addMessage', -1, {
        args = { '^3[Patrol Vote]', ("Vote started to %s patrol! Type /yes or /no to vote."):format(type == 'end' and 'END' or 'CONTINUE') }
    })

    SetTimeout(voteTimeout * 1000, function()
        announceResults()
    end)
end

RegisterCommand('voteend', function(source)
    if not hasPermission(source) then
        TriggerClientEvent('chat:addMessage', source, {
            args = { '^1[Error]', 'You do not have permission to run this command.' }
        })
        return
    end
    startVote(source, 'end')
end, false)

RegisterCommand('votecontinue', function(source)
    if not hasPermission(source) then
        TriggerClientEvent('chat:addMessage', source, {
            args = { '^1[Error]', 'You do not have permission to run this command.' }
        })
        return
    end
    startVote(source, 'continue')
end, false)

RegisterCommand('yes', function(source)
    if not votingInProgress then
        TriggerClientEvent('chat:addMessage', source, {
            args = { '^1[Vote]', 'No vote is currently active.' }
        })
        return
    end

    local list = (voteType == 'end') and votes["end"] or votes.continue

    for _, id in pairs(list) do
        if id == source then
            TriggerClientEvent('chat:addMessage', source, {
                args = { '^1[Vote]', 'You already voted.' }
            })
            return
        end
    end

    table.insert(list, source)

    if voteStarter then
        TriggerClientEvent('chat:addMessage', voteStarter, {
            args = { '^3[Vote]', ('Player %s voted YES to %s patrol.'):format(GetPlayerName(source), voteType:upper()) }
        })
    end
end, false)

RegisterCommand('no', function(source)
    if not votingInProgress then
        TriggerClientEvent('chat:addMessage', source, {
            args = { '^1[Vote]', 'No vote is currently active.' }
        })
        return
    end

    local list = (voteType == 'end') and votes.continue or votes["end"]

    for _, id in pairs(list) do
        if id == source then
            TriggerClientEvent('chat:addMessage', source, {
                args = { '^1[Vote]', 'You already voted.' }
            })
            return
        end
    end

    table.insert(list, source)

    if voteStarter then
        TriggerClientEvent('chat:addMessage', voteStarter, {
            args = { '^3[Vote]', ('Player %s voted NO to %s patrol.'):format(GetPlayerName(source), voteType:upper()) }
        })
    end
end, false)
